#!/bin/bash

#   __|    \    _ \  |      _ \   __| __ __| __ __|
#  (      _ \     /  |     (   | (_ |    |      |
# \___| _/  _\ _|_\ ____| \___/ \___|   _|     _|

# cli_scripts/amazon_handler/update_hosts_d.sh
# Created 1/20/25 - 11:39 AM UK Time (London) by carlogtt

# Script Paths
script_dir_abs="$(realpath -- "$(dirname -- "${BASH_SOURCE[0]}")")"
declare -r script_dir_abs
cli_scripts_dir_abs="$(realpath -- "${script_dir_abs}/../")"
declare -r cli_scripts_dir_abs

# Sourcing base file
. "${cli_scripts_dir_abs}/base.sh" || echo -e "[$(date '+%Y-%m-%d %T %Z')] [ERROR] Failed to source base.sh"

# Script Options
set -o errexit  # Exit immediately if a command exits with a non-zero status
set -o pipefail # Exit status of a pipeline is the status of the last cmd to exit with non-zero

# User defined variables
update_etc_hosts_daemon() {
    local hosts_launchd_daemon_path hosts_launchd_daemon_label
    hosts_launchd_daemon_label="com.icarus.hosts.update"
    hosts_launchd_daemon_path="/Library/LaunchDaemons/com.icarus.hosts.update.plist"

    echo -e "We need to briefly run as root (through sudo) to execute some commands."
    echo -e "If prompted, please enter your user password."
    sudo -v

    echo -e "\nWriting launchd daemon configuration"

    cat <<EOF | sudo tee "${hosts_launchd_daemon_path}" >/dev/null
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
    <dict>

        <key>Label</key>
        <string>${hosts_launchd_daemon_label}</string>

        <key>StartCalendarInterval</key>
        <dict>
            <key>Minute</key>
            <integer>00</integer>
        </dict>

        <key>StandardOutPath</key>
        <string>${tmp_root_sudo}/log/${hosts_launchd_daemon_label}.log</string>

        <key>StandardErrorPath</key>
        <string>${tmp_root_sudo}/log/${hosts_launchd_daemon_label}.log</string>

        <key>ProgramArguments</key>
        <array>
            <string>${this_cli_fullpath}</string>
            <string>-v</string>
            <string>amazon</string>
            <string>update-hosts</string>
        </array>

    </dict>
</plist>
EOF

    sudo chown root:wheel ${hosts_launchd_daemon_path}
    sudo chmod 644 ${hosts_launchd_daemon_path}

    echo -e "launchd daemon configuration was successfully written to"
    echo -e "${hosts_launchd_daemon_path}"

    echo -e "\nLoading launchd daemons configuration"
    echo -e "loading ${hosts_launchd_daemon_path}"

    sudo launchctl disable "system/${hosts_launchd_daemon_label}" || {
        echo -e "${hosts_launchd_daemon_label} failed to disable"
    }

    sudo launchctl bootout "system/${hosts_launchd_daemon_label}" || {
        echo -e "${hosts_launchd_daemon_label} failed to bootout"
    }

    sudo launchctl enable "system/${hosts_launchd_daemon_label}" || {
        echo -e "${hosts_launchd_daemon_label} failed to enable"
    }

    sudo launchctl bootstrap "system" "${hosts_launchd_daemon_path}" || {
        echo -e "${hosts_launchd_daemon_label} failed to bootstrap"
    }

    echo -e "Configuration loaded"
}

update_etc_hosts_daemon "$@"
